SPOUTPANEL

SpoutPanel is a program that can be activated by Spout receiver to select the sender to receive from. The path for SpoutPanel.exe is established by using SpoutSettings or opening the application once. Receivers will then open that version.

"Select" - select the sender to receive from
"Refresh" - refresh the list if snders have been aded or removed while SpoutPanel is open.

Option buttons

The sender texture description is a button that brings up sender details and diagnostics.

"Copy" - save to the clipboard.
"Logs" - open the folder containing Spout application logs

If any receiving errors occur, open the log folder and examine the Demo Receiver log.





