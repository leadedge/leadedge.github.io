### Videos recorded using the demo receiver are saved here.

### Adding audio to a video file

* Record a video to this folder using the Spout Receiver
* Copy the mp3 audio file to this folder
* Run "aa-audio.bat" to add audio from a file to a video

"aa-dos.bat" - opens a command prompt window


