SPOUTPANEL

SpoutPanel is a program that can be activated by Spout receiver to select the sender to receive from. The path for SpoutPanel.exe is established by using SpoutSettings or opening the application once. Receivers will then open that version.

"Select" - select the sender to receive from
"Refresh" - refresh the list if snders have been aded or removed while SpoutPanel is open.

Texture description

The sender texture description is a button that brings up sender details and diagnostics.

"Logs" - open the folder containing Spout application logs
"Copy" - save diagnostics to the clipboard.

If any errors occur with the demo sender or demo receiver, open the log folder and examine "SpoutSender.log" or "SpoutReceiver.log".





