SPOUTSETTINGS

SpoutSettings is a utility program to change the operation mode for Spout applications.

Installation is not required. If a previous Spout installation is detected, the option for removal is recommended. If the un-installation is not successful, close SpoutSettings and use Windows Control Panel to un-install Spout.

Help buttons describe all options.

Options are saved in the registry under "Computer\HKEY_CURRENT_USER\Software\Leading Edge\Spout".

The path to "SpoutPanel" sender selection dialog is also recorded in the registry for receivers to find.

