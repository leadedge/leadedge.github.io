Spout demonstration programs

Version 2.007.013 has new demo receiver and sender applications built with Openframeworks and [published on GitHub](https://github.com/leadedge/ofSpoutDemo). The project can be built as either sender or receiver and includes recorder and shader classes which are not part of the main Spout repository.

The sender allows selection of output format, such as 16 bit unsigned or 16 and 32 bit float.

The receiver has image adjust functions, using high speed compute shaders, for brightness, contrast, saturation, gamma and sharpness including an "Adaptive" sharpen option that activates [Contrast Adaptive Sharpening](https://gpuopen.com/fidelityfx-cas/), developed by AMD. This reduces edge ringing and produces a subtle and effective sharpening effect. As well as full screen display, the image can be re-sent for input into other programs.

Video recording, as introduced in 2.007.012, remains. Image capture has the additional option of "Luminance HDR" High Dynamic Range for 32bit float textures such as produced by TouchDesigner. High contrast range images can be processed using [tone mapping](https://sourceforge.net/projects/qtpfsgui/) to select brightness and contrast levels for low dynamic range displays.

"SpoutSettings" and the sender selection program "SpoutPanel" have been revised for improved diagnostics that should help trace any problems if they occur. For developers, "SpoutPanel" is now activated for "modeless" display of SpoutMessageBox which can be used if freeze of the host application is undesirable. SpoutMessageBox includes custom icons, multiple buttons, urls that are active anywhere in the text and a timeout for brief notices.

Spout SDK files have been improved and can be used without changing existing source code. Details of new additions can be found in the documentation and source code. Binaries for the libraries and example programs are now included as part of the distribution.
