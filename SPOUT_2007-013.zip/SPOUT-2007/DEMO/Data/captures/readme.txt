### Images captured using the receiver are saved here.
