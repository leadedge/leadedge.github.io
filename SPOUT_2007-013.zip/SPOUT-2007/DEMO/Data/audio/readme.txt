##VIRTUAL AUDIO DEVICE

A virtual audio device that captures what you hear from the speakers, developed by Roger Pack.

https://github.com/rdp/virtual-audio-capture-grabber-device

The device is a DirectShow filter and can be used with FFmpeg to record the audio. This allows SpoutRecorder to record system audio together with the video.

All files are located in the "VirtualAudio" folder.

VirtualAudioRegister.exe can be used to register or un-register the filters.
This has Administrator privileges and Windows UAC might intercept, but just allow it.

If "virtual-audio-capturer" has not been registered, click the 'Register' button.\ 
This will register both 32 bit and 64 bit versions.\
After confirmation of success, the button will show 'UnRegister'.\
Click 'Unregister' to remove it from the system.

To update to new dll files, click 'Unregister' and then 'Register' again.
				
You can also register manually. There are separate folders for 32 bit and 64 bit versions and you can install both on a 64 bit system. In each folder you will find "_register_run_as_admin.bat". RH click and "Run as Administrator" to register. Register the 32 bit version first.

SYSTEM SOUNDS

The audio capture also includes any system sounds which will be recorded. In particcular a beep when the volume is adjusted.
This, as well as other system sounds, can be prevented :

To mute the volume adjust beep

1) Open control panel
2) Select the "Sound" option
2) Click the the "Sounds" tab
4) Select "Default Beep" in the "Program Events" list (or other system sound)
5) At the bottom "Sounds" list, select (None)
6) Click "Apply" and "OK"

To mute all system sounds

1) Open "Settings"
2) Select "System > Sound"
3) Scroll down to "Advanced sound options"
4) Select "App volume and device preferences"
5) Click on the speaker icon for "System sounds" to mute all

