### FFmpeg.exe is required in this folder

* Go to https://github.com/GyanD/codexffmpeg/releases
* Choose the "Essentials" build. e.g. "ffmpeg-6.0-essentials_build.zip" and download the archive.
* Unzip the archive and copy "bin\ffmpeg.exe" to here : "bin\data\ffmpeg"



