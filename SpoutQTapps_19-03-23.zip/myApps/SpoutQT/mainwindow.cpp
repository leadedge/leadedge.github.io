#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMouseEvent>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    spoutTest = new SIO();

    //Communication between GUI and spout object
    QObject::connect(spoutTest, SIGNAL(processed(QImage,QImage)), this, SLOT(update(QImage,QImage)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::update(const QImage &imgS, const QImage &imgR)
{    
    ui -> lSend -> setPixmap(QPixmap::fromImage(imgS).scaled(ui -> lSend -> size(), Qt::KeepAspectRatio, Qt::FastTransformation));
    ui -> lReceive -> setPixmap(QPixmap::fromImage(imgR).scaled(ui -> lReceive -> size(), Qt::KeepAspectRatio, Qt::FastTransformation));
}

void MainWindow::mouseReleaseEvent(QMouseEvent *e)
{
    if(e->button() == Qt::RightButton)
    {
        spoutTest->selectSender();
    }

}
