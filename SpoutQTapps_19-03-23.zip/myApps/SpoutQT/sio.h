#ifndef SIO_H
#define SIO_H

#include <SpoutLibrary.h>
#include <QDebug>

#include <QThread>
#include <QMutex>
#include <QWaitCondition>
#include <QImage>

class SIO : public QThread
{
    Q_OBJECT

private:

    QMutex mutex;
    QWaitCondition condition;

    // Spout sender and receiver pointers
    SPOUTLIBRARY * spoutSenderPtr;
    SPOUTLIBRARY * spoutReceiverPtr;

    // OpenGL created
    bool spoutInitialized ;

    // Send and receive images
    QImage imgSend, imgReceive;

public:

    void run();

    void receive(unsigned char* image);
    void selectSender();
    void mSleep(int mS);

    SIO(QObject *parent = nullptr);
    ~SIO();

protected:

signals:

    //Sends images to GUI
    void processed(const QImage &imgS, const QImage &imgR);
};

#endif // SIO_H
