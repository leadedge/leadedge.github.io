#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QString>

#include "sio.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

    //Spout object
    SIO* spoutTest;

private slots:

    //Receives images from spout object
    void update(const QImage &imgS, const QImage &imgR);

    void mouseReleaseEvent(QMouseEvent *e);
};

#endif // MAINWINDOW_H
