// ============================================================================
//
//  19.03.23    Updated to 2.007 methods and updated SpoutLibrary
//              Tested with QT 5.13.0, MSVC 2017 64 bit
//              with SpoutLibrary 64 bit for Visual Studio
// ============================================================================

#include "sio.h"

#include <QImage>

SIO::SIO(QObject *parent) : QThread(parent)
{
    // SpoutLibrary pointers
    // Independent for sender and receiver
    spoutSenderPtr = GetSpout();
    spoutReceiverPtr = GetSpout();

    // Logging options
    spoutSenderPtr->EnableSpoutLog();
    // spoutSenderPtr->EnableSpoutLogFile("SIO");
    // spoutSenderPtr->SetSpoutLogLevel(SPOUT_LOG_WARNING);

    QImage img;

    // Splash image
    if(img.load("../SpoutQT/test.jpg"))
    {
        imgSend = img.convertToFormat(QImage::Format_RGBA8888, Qt::AutoColor);
        spoutSenderPtr -> SpoutLogNotice("SpoutQT - Loaded image OK");
        spoutSenderPtr -> SpoutLogNotice("    %dx%d - format %d", imgSend.width(), imgSend.height(), imgSend.format());
    }

    // OpenGL context flag
    spoutInitialized = false;

    // Create an empty image to avoid null Pixmap errors
    imgReceive = QImage(256,256,QImage::Format_RGBA8888);
    imgReceive.fill(0);

    start(LowPriority);
}

void SIO::run()
{

    // Create an OpenGL context in this thread
    if(!spoutInitialized )
    {
        spoutSenderPtr -> SpoutLogNotice("spoutSenderPtr -> CreateOpenGL()");

        if(spoutSenderPtr -> CreateOpenGL())
        {
            spoutSenderPtr -> SpoutLogNotice("SpoutQT - InitOpenGL OK");

            // Give the sender a name
            spoutSenderPtr->SetSenderName("QT SIO SENDER");

            // All OK
            spoutInitialized  = true;
        }
        else
        {
            spoutSenderPtr -> SpoutLogNotice("SpoutQT - Could not create OpenGL window\n");
        }
    }


    while(true)
    {
        // If an OpenGl context was created, send and receive
        if(spoutInitialized )
        {
            spoutSenderPtr -> SpoutLogNotice("SendImage");

            // Sender
            spoutSenderPtr-> SendImage(imgSend.bits(), static_cast<unsigned int>(imgSend.width()), static_cast<unsigned int>(imgSend.height()), GL_RGBA);

            // Receiver - allow for update
            this->receive(imgReceive.bits());

             // Send images to GUI
            emit processed(imgSend, imgReceive);
       }

        // SpoutLibrary function to hold fps
        spoutSenderPtr->HoldFps(30);

    }
}


void SIO::receive(unsigned char* image)
{

    // For a program with both sender and receiver,
    // do not receive from self
    char name[256]={};
    if(spoutReceiverPtr -> GetActiveSender( name ) ) {
        if( strcmp("QT SIO SENDER", name) == 0) { // Our sender
            return;
        }
    }

    // Receive into "image"
    if(spoutReceiverPtr -> ReceiveImage(image))
    {
        // If updated due to sender size change, update the receiving image
        if(spoutReceiverPtr -> IsUpdated()) {
            imgReceive = QImage(static_cast<int>(spoutReceiverPtr->GetSenderWidth()),
                                static_cast<int>(spoutReceiverPtr->GetSenderHeight()),
                                QImage::Format_RGBA8888);
        }
   }
   else
   {
        spoutReceiverPtr->SpoutLogNotice("SpoutQT - Failed to receive image from sender");
        spoutReceiverPtr -> ReleaseReceiver();
   }

}

void SIO::selectSender()
{
    spoutReceiverPtr->SelectSender();
}

void SIO::mSleep(int mS)
{
    Sleep(static_cast<DWORD>(mS));
}

SIO::~SIO()
{
    if(spoutInitialized)
    {
       spoutReceiverPtr -> ReleaseReceiver();
       spoutReceiverPtr -> Release();
       spoutSenderPtr -> ReleaseSender();
       spoutSenderPtr -> CloseOpenGL();
       spoutSenderPtr -> Release();
    }

    mutex.lock();

    condition.wakeOne();

    mutex.unlock();

    quit();
    wait();
}
