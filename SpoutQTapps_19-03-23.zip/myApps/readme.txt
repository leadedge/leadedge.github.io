QT test projects

SpoutQT (2018) by :
Roham Tavakkoli <rohamtavakkoli@gmail.com>

SpoutQml (2020) by :
Kevin Kleinke <kevin.kleinke@allround-team.com>

Both projects use SpoutLibrary
SpoutQT 64 bit
SpoutQml 32 bit
SpoutQT is updated to the latest 2.007 methods, Creates an OpenGL context and uses pixel images
SpoutQml uses OpenGL textures

SpoutLibrary should be downloaded from the Spout beta branch
Binaries are up to date

https://github.com/leadedge/Spout2/tree/beta/SPOUTSDK/SpoutLibrary





