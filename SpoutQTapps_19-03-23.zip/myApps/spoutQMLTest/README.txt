Author: Kevin Kleinke
Mail: kevin.kleinke@allround-team.com

Used Qt version: 5.11.1
Used compiler: mingw53_32

SpoutQMLExample

This project consists of two new QML objects, which are based on the Spout.
The TextureCapturing QML type is an implementation of SpoutSender, which takes the window it is placed in, and guides the texture into an FBO.
There it is provided to a SpoutSender and send.

The TextureImage QML type is an unfinished implementation of a Spout Receiver, which should receive a texture and later display it similar to an 
QML Image type. Currently, it is only possible to connect and test if receiving was successful via debug loggings in the console.

Note that this project is completly in developement and may cause errors or could crash.