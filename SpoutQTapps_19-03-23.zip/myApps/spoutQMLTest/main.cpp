#include <QApplication>
#include <QtQml>
#include <QtQuick>

#include "lib/texturecapturing.h"
#include "lib/textureimage.h"

int main(int argc, char *argv[])
{
        QGuiApplication app(argc, argv);

        qmlRegisterType<TextureCapturing>("TextureTools",1,0,"TextureCapturing");
        qmlRegisterType<TextureImage>("TextureTools",1,0,"TextureImage");

        QQuickView view;
        view.setResizeMode(QQuickView::SizeRootObjectToView);
        view.setSource(QUrl("qml/main.qml"));
        view.show();

        return app.exec();
    }
