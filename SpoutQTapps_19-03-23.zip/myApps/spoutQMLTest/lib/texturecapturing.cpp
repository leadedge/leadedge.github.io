#include "texturecapturing.h"

TextureCapturing::TextureCapturing() : QObject()
{
    qDebug()<< "TextureCapturing";
    m_spoutptr = GetSpout(); // Create an instance of the Spout library

    m_spoutptr->EnableSpoutLog();

    m_spoutptr->SpoutLog( "TextureCapturing");

    m_initTimer.singleShot(500,this,SLOT(init())); //Delay startup, wait for QML-part to be complete
}

TextureCapturing::~TextureCapturing()
{
    if(m_spoutptr) {
        qDebug()<< "Releasing Spout";
        m_spoutptr->ReleaseSender(); // Release the sender
        m_spoutptr->Release(); // Release the Spout library instance
    }
}

bool TextureCapturing::sending()
{
    return m_sending;
}

QString TextureCapturing::senderName()
{
    return m_senderName;
}

void TextureCapturing::setSending(bool sending)
{
    if(m_sending != sending){
        m_sending = sending;
        emit sendingChanged();
    }
}

void TextureCapturing::setSenderName(QString senderName)
{
    if(m_senderName != senderName){
        qDebug()<<"Setting senderName to " << senderName;
        m_senderName = senderName;
        m_spoutptr->SpoutLog("Setting senderName to %s", m_senderName.toStdString().c_str());
        if(m_senderExists)m_spoutptr->UpdateSender(m_senderName.toStdString().c_str(),
                                                   static_cast<unsigned int>(m_windowWidth),
                                                   static_cast<unsigned int>(m_windowHeight));
        emit senderNameChanged();
    }
}

void TextureCapturing::init()
{
    m_parent = qobject_cast<QQuickItem*>(this->parent());
    if(m_parent){
        qDebug()<< m_parent->window();
        m_window = m_parent->window();
        connect(m_window, &QQuickWindow::afterRendering,
                this, &TextureCapturing::update, Qt::DirectConnection);
    }
    qDebug() << "Spout init complete";
}

void TextureCapturing::renderWindow() //Render content for QML window instead of framebuffer, otherwise QML window would always be black
{
    qDebug() << "renderWindow";
    m_window->setRenderTarget(nullptr);
    m_skipFBO = true;
    m_window->update();
}


void TextureCapturing::update()
{
    if(!m_skipFBO){

    if(m_windowHeight != m_window->size().height() || m_windowWidth != m_window->size().width()){
        m_windowHeight = m_window->size().height();
        m_windowWidth =  m_window->size().width();
        if(m_senderExists) {

            qDebug() << "Update sender : " << m_windowWidth << " x " << m_windowHeight;

            m_spoutptr->SpoutLog("Update sender :  %dx%d", m_windowWidth, m_windowHeight);


            m_spoutptr->UpdateSender(m_senderName.toStdString().c_str(),
                                     static_cast<unsigned int>(m_windowWidth),
                                     static_cast<unsigned int>(m_windowHeight));
            delete m_fbo;
            m_fbo = new QOpenGLFramebufferObject(m_windowWidth, m_windowHeight, m_format);
            m_window->setRenderTarget(m_fbo);
        }
    }

    if(!m_senderExists){


        m_spoutptr->SpoutLog("Creating sender : %s", m_senderName.toStdString().c_str());

        m_senderExists = m_spoutptr->CreateSender(m_senderName.toStdString().c_str(),
                                                  static_cast<unsigned int>(m_windowWidth),
                                                  static_cast<unsigned int>(m_windowHeight));

        m_format.setAttachment(QOpenGLFramebufferObject::CombinedDepthStencil);
        m_format.setMipmap(false);
        m_format.setSamples(0);
        m_format.setTextureTarget(GL_TEXTURE_2D);
        m_format.setInternalTextureFormat(GL_RGBA8);

        qDebug() << "New sender : " << m_windowWidth << " x " << m_windowHeight;

        m_fbo = new QOpenGLFramebufferObject(m_windowWidth, m_windowHeight, m_format);

        qDebug() << "New fbo : " << m_fbo->width() << " x " << m_fbo->height();

        m_window->setRenderTarget(m_fbo);
    }


    // setSending(m_spoutptr->SendTexture(m_fbo->texture(), GL_TEXTURE_2D,
    //                                   static_cast<unsigned int>(m_windowWidth),
    //                                   static_cast<unsigned int>(m_windowHeight) ));

    qDebug() << "Sending fbo : " << m_fbo->width() << " x " << m_fbo->height();

    setSending(m_spoutptr->SendFbo(m_fbo->handle(),
                                   static_cast<unsigned int>(m_fbo->width()),
                                   static_cast<unsigned int>(m_fbo->height()) ));

    if(m_sending) qDebug() << "Currently sending with name: " << m_senderName;
    else qDebug() << "Sending error";
    renderWindow();
    }else{
        m_skipFBO = false;
        m_window->setRenderTarget(m_fbo);
    }
}






