#ifndef TEXTURECAPTURING_H
#define TEXTURECAPTURING_H


#include <QObject>
#include <QtQuick>
#include "SpoutLibrary.h"
#include <QOpenGLFramebufferObject>
#include <QQuickWindow>
#include <QOpenGLFunctions>

class TextureCapturing : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool sending READ sending NOTIFY sendingChanged)
    Q_PROPERTY(QString senderName READ senderName WRITE setSenderName NOTIFY senderNameChanged)

public:
    explicit TextureCapturing();
    ~ TextureCapturing ();
    bool sending();
    QString senderName();
    void setSending(bool sending);
    void setSenderName(QString senderName);

signals:
    void sourceChanged();
    void sendingChanged();
    void senderNameChanged();

public slots:
    void update();
    void init();

private:
    QQuickItem *m_parent = nullptr;
    QQuickWindow *  m_window = nullptr;
    SPOUTLIBRARY* m_spoutptr = nullptr;
    bool m_senderExists = false;
    QOpenGLFramebufferObject * m_fbo = nullptr;
    int m_windowHeight = 0;
    int m_windowWidth = 0;
    QOpenGLFramebufferObjectFormat m_format;
    QTimer m_initTimer;
    bool m_sending = false;
    QString m_senderName = "QMLSender";

    int debug_attempts = 0;
    bool rec_Connected = false;


    void renderWindow();
    bool m_skipFBO = false;

    QTimer m_viewTimer;

};

#endif // TEXTURECAPTURING_H

