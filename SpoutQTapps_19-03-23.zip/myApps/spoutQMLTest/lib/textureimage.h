#ifndef TEXTUREIMAGE_H
#define TEXTUREIMAGE_H

#include <QObject>
#include <QtQuick>
#include "SpoutLibrary.h"
#include <QOpenGLFramebufferObject>
#include <QQuickWindow>
#include <QOpenGLFunctions>

class TextureImage : public QObject
{
Q_OBJECT
    Q_PROPERTY(bool receiving READ receiving NOTIFY receivingChanged)
    Q_PROPERTY(QString senderName READ senderName WRITE setSenderName NOTIFY senderNameChanged)
public:
    TextureImage();
    ~ TextureImage ();
    bool receiving() const;
    QString senderName() const;
    void setReceiving(bool receiving);
    void setSenderName(QString senderName);
signals:
    void receivingChanged();
    void senderNameChanged();

public slots:
    void update();
    void init();

private:
    SPOUTLIBRARY* m_spoutptr = nullptr; // A sender object
    QOpenGLFramebufferObject * m_fbo = nullptr;
    QQuickItem *m_parent = nullptr;
    QQuickWindow *  m_window = nullptr;
    QTimer m_initTimer;
    bool m_receiving = false;
    QString m_senderName = "QMLSender";
    unsigned int m_targetWidth;
    unsigned int m_targetHeight;
    int m_attempts = 0;

     void renderWindow();

};



#endif // TEXTUREIMAGE_H
