#include "textureimage.h"

TextureImage::TextureImage(): QObject()
{
   m_spoutptr = GetSpout(); // Create an instance of the Spout library
   m_initTimer.singleShot(500,this,SLOT(init())); //Delay startup, wait for QML-part to be complete

   if(m_spoutptr) {
        qDebug()<< "GetSpout() OK";
        m_spoutptr->EnableSpoutLog();
        m_spoutptr->SpoutLog( "TextureImage");
   }
   else {
       qDebug()<< "GetSpout() failed";
   }
}

TextureImage::~TextureImage()
{
    if(m_spoutptr) {
        qDebug()<< "Releasing Spout";
        m_spoutptr->ReleaseReceiver(); // Release the sender
        m_spoutptr->Release(); // Release the Spout library instance
    }
}

bool TextureImage::receiving() const
{
    return m_receiving;
}

QString TextureImage::senderName() const
{
    return m_senderName;
}

void TextureImage::setReceiving(bool receiving)
{
    if(receiving != m_receiving){
        m_receiving = receiving;
        emit receivingChanged();
    }
}

void TextureImage::setSenderName(QString senderName)
{
    if(m_senderName != senderName){
        qDebug()<<"Setting senderName to " << senderName;
        m_senderName = senderName;
        emit senderNameChanged();
    }
}


void TextureImage::init()
{
    m_parent = qobject_cast<QQuickItem*>(this->parent());
    if(m_parent){
        qDebug()<< m_parent->window();
        m_window = m_parent->window();
        connect(m_window, &QQuickWindow::afterRendering,
                this, &TextureImage::update, Qt::DirectConnection);
        m_window->update();
    }
    qDebug() << "Spout init complete";

}

void TextureImage::update()
{
    qDebug()<< "TextureImage::update() - Current senders: " << m_spoutptr->GetSenderCount();

    m_attempts = 0;
    unsigned int w = 500, h=500;
    QString namestr; // received sender name


    char* name = new char[m_senderName.toStdString().length() + 1];
    std::vector<char> cstr(m_senderName.toStdString().c_str(), m_senderName.toStdString().c_str() + m_senderName.toStdString().size() + 1);

    // LJ DEBUG
    while(m_attempts<10) {
        setReceiving(m_spoutptr->ReceiveTexture());
        m_attempts++;
    }
    if(m_receiving) {
        qDebug()<< "Attempt : " << m_attempts++ << "received OK";
    }
    else {
        qDebug()<< "Attempt : " << m_attempts++ << "receive failed";
    }

    /*
    while(!m_receiving && m_attempts<10) {
        setReceiving(m_spoutptr->CreateReceiver(name,w,h));
        qDebug()<< "Created receiver: " << m_receiving;
        qDebug()<< "Attempts: " << m_attempts++;
    }
    */

    if(m_receiving) {

        qDebug()<< "Received texture: " << m_spoutptr->ReceiveTexture();

        namestr = m_spoutptr->GetSenderName();
        w = m_spoutptr->GetSenderWidth();
        h = m_spoutptr->GetSenderHeight();
        // also
        // m_spoutptr->GetSenderFps();
        // m_spoutptr->GetSenderFrame();

        //
        // Sender OpenGL shared texture
        //
        // GLuint texID = m_spoutptr->GetSharedTextureID();
        // Target is GL_TEXTURE2D
        //
        // Utility copy texture funcion
        // bool CopyTexture(GLuint SourceID, GLuint SourceTarget,
        //          GLuint DestID, GLuint DestTarget,
        //          unsigned int width, unsigned int height,
        //          bool bInvert, GLuint HostFBO);

        if(m_spoutptr->IsUpdated()) {
            qDebug()<< "Updated:  ";
        }
        else {
            qDebug()<< "Same sender :  ";
        }

        qDebug()<<"    Name   " << namestr;
        qDebug()<<"    Width  " << w;
        qDebug()<<"    Height " << h;

    }


    delete [] name;
}

void TextureImage::renderWindow()
{
    qDebug() << "renderWindow";

    // m_window->setRenderTarget(0);
    // m_skipFBO = true;
    // m_window->update();
}


