Receive Copy option

The received texture, opened from the sender share handle, is copied to the top left region of a larger DirectX texture linked to OpenGL. The region dimensions are the same as the received texture and the OpenGL texture copy functions are not affected.
	
If the received texture is larger, the linked texture is re-created and re-registered with the GL/DX interop. If smaller, no action is required.
	
By default, the received texture is re-registered with the GL/DX interop for a size change.


Registry settings

The option and texture size can be changed with registry keys.
"Computer\HKEY_CURRENT_USER\SOFTWARE\Leading Edge\Spout"
    ReceiveCopy (0/1)
	ReceiveWidth (value as required)
	ReceiveHeight (value as required)
	
A batch file "receive-copy.bat" can be used to make the registry changes.


Building the library

Unzip SpoutGL_12-06-23_Receive-Copy.zip
Copy all the files into the "SpoutGL" folder
Build the library using CMake as documented

