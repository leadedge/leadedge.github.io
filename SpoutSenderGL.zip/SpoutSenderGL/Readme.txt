	SpoutSenderGL.dll

	FFGL 2.2 plugin for sending OpenGL texture to a Spout receiver.
	Sends using GPU for compatible hardware, otherwise via CPU memory.

	Copy SpoutSenderGL.dll to "...\Documents\Resolume Arena\Extra Effects"
	or another folder that has been assigned for FreeframeGL plugins.
	Find SpoutSenderGL in the list of Effects.
	Drop on top of any cell that renders an image.
	Scroll down the clip window and find SpoutSenderGL at the bottom.
	Enter a name for the sender.

	Receive with the Spout Demo Receiver or any application with Spout support.

	A log file "SpoutSenderGL.log" is produced to help trace errors.
	Find it from "Diagnostics -> Logs" with either SpoutSettings
	or the Spout Demo Receiver -> Help.
	