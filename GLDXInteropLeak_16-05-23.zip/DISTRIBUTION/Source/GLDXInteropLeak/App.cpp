//
// WGL_NV_DX_interop leak test for inter-process texture sharing
//
// https://registry.khronos.org/OpenGL/extensions/NV/WGL_NV_DX_interop2.txt
//
// http://spout.zeal.co/
//
// To build, open GLDXInteropLeak.sln with Visual Studio 2022
// For D3D11 debug log reporting, select configuration debug and Debug > Start debugging.
//
// To use :
//
// Monitor Dedicated Memory of the program with TaskManager > Details
// Dedicated Memory has to be added to the Task Manager columns.
//
// Start a Spout sender to test open of sender texture handle.
// Change options on program start.
//
// Based on :
// https://community.intel.com/t5/Graphics/Memory-leak-caused-by-NV-DX-interop/m-p/1122143#M87670
//

#include "stdafx.h"
#include <atlbase.h>
#define COBJMACROS
#define INITGUID

#include <intrin.h>
#include <windows.h>
#include <d3d11.h>
#include <gl/GL.h>
#include <AccCtrl.h>
#include <conio.h> // for _getch
#include <debugapi.h> // for debugger attached detect

#include "glext.h"
#include "wglext.h"
#include "SpoutGL\SpoutSenderNames.h" // to detect spout sender

#pragma comment (lib, "d3d11.lib")
#pragma comment (lib, "opengl32.lib")

#define MAX_LOADSTRING 100

// Global Variables:
ID3D11Device* g_pd3dDevice = nullptr;
ID3D11DeviceContext* g_pImmediateContext = nullptr;
ID3D11Texture2D* g_pSharedTexture = nullptr;
HANDLE g_dxShareHandle = nullptr;
GLuint g_glTexture = 0;
HANDLE g_hInteropDevice = nullptr;
HANDLE g_hInteropObject = nullptr;
unsigned int g_Width = 640;
unsigned int g_Height = 360;
int ntests = 1; // Number of tests

// Spout sender
spoutSenderNames senders;
char sendername[256]={};
unsigned int senderwidth = 0;
unsigned int senderheight = 0;
DWORD senderformat = 0;
ID3D11Texture2D* g_pReceivedTexture = nullptr;
HANDLE g_dxReceivedHandle = nullptr;
HDC g_hDC = nullptr;
HGLRC g_hRC = nullptr;
HWND g_hWnd = nullptr;


// Functions
void InitWglProcs();
void InitOpenGL();
ID3D11Device* CreateDX11device();
unsigned long ReleaseDX11device(ID3D11Device* pd3dDevice);
bool CreateSharedDX11texture(ID3D11Device* pDevice, unsigned int width, unsigned int height, 
	DXGI_FORMAT format, ID3D11Texture2D** ppTexture, HANDLE& dxShareHandle, bool bKeyed = false);
unsigned long ReleaseDX11Texture(ID3D11Device* pd3dDevice, ID3D11Texture2D* pTexture);
bool OpenDX11shareHandle(ID3D11Device* pDevice, ID3D11Texture2D** ppSharedTexture, HANDLE dxShareHandle);
void FlushWait(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pImmediateContext);
void Wait(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pImmediateContext);

void CleanupTextures();

GLint GLmemory(); // Memory reported
GLint mem_kb[4]={};
GLint maxTotal = 0; // Starting memory

void DebugLog(ID3D11Device* pd3dDevice, const char* format, ...);
void GLDXLeakTest(ID3D11Texture2D* pTexture, GLint glTexture);

// WGL/DX functions
#define WGL_ACCESS_READ_ONLY_NV           0x00000000
#define WGL_ACCESS_READ_WRITE_NV          0x00000001
#define WGL_ACCESS_WRITE_DISCARD_NV       0x00000002
typedef BOOL(WINAPI* PFNWGLDXSETRESOURCESHAREHANDLENVPROC) (void* dxObject, HANDLE shareHandle);
typedef HANDLE(WINAPI* PFNWGLDXOPENDEVICENVPROC) (void* dxDevice);
typedef BOOL(WINAPI* PFNWGLDXCLOSEDEVICENVPROC) (HANDLE hDevice);
typedef HANDLE(WINAPI* PFNWGLDXREGISTEROBJECTNVPROC) (HANDLE hDevice, void* dxObject, GLuint name, GLenum type, GLenum access);
typedef BOOL(WINAPI* PFNWGLDXUNREGISTEROBJECTNVPROC) (HANDLE hDevice, HANDLE hObject);
typedef BOOL(WINAPI* PFNWGLDXOBJECTACCESSNVPROC) (HANDLE hObject, GLenum access);
typedef BOOL(WINAPI* PFNWGLDXLOCKOBJECTSNVPROC) (HANDLE hDevice, GLint count, HANDLE* hObjects);
typedef BOOL(WINAPI* PFNWGLDXUNLOCKOBJECTSNVPROC) (HANDLE hDevice, GLint count, HANDLE* hObjects);

PFNWGLDXOPENDEVICENVPROC wglDXOpenDeviceNV = NULL;
PFNWGLDXSETRESOURCESHAREHANDLENVPROC wglDXSetResourceShareHandleNV = NULL;
PFNWGLDXREGISTEROBJECTNVPROC wglDXRegisterObjectNV = NULL;
PFNWGLDXUNREGISTEROBJECTNVPROC wglDXUnregisterObjectNV = NULL;
PFNWGLDXCLOSEDEVICENVPROC wglDXCloseDeviceNV = NULL;
PFNWGLDXLOCKOBJECTSNVPROC wglDXLockObjectsNV = NULL;
PFNWGLDXUNLOCKOBJECTSNVPROC wglDXUnlockObjectsNV = NULL;
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// Main console application
int main()
{
	printf("WGL_NV_DX_interop2 leak test\n\n");

	printf("Open Task Manager and select 'Details'\n");
	printf("Add column 'Dedicated Memory' if it is not present\n");
	printf("Find 'GLDXInteropLeak.exe' and monitor 'Dedicated Memory'.\n");
	printf("Open a Spout sender for options 1-4.\n\n");

	printf("Press a key to select an option\n");
	printf("'Shift key' for a single test\n");
	printf("  0 - Create new D3D11 texture\n");
	printf("  1 - Open D3D11 texture from sender handle\n");
	printf("  2 - Open sender texture from sender handle\n");
	printf("  3 - Copy sender texture to D3D11 texture\n");
	printf("  4 - Copy sender texture to D3D11 texture with Keyed mutex\n\n");
	printf("ESC - quit\n");
	printf("Any other key for default option 0\n\n");

	int option = _getch();

	// ESC exit
	if (option ==  VK_ESCAPE)
		return 0;

	// Single test for debugging (shift 1-5)
	ntests = 1;
	if (option == (int)')') option = 0;
	else if (option == (int)'!') option = 1;
	else if (option == (int)'@') option = 2;
	else if (option == (int)'#') option = 3;
	else if (option == (int)'$') option = 4;
	else {
		option = option-48;
		// ntests = 10000;
		ntests = 100000000;
	}

	if (option < 0 || option > 4)
		option = 0;

	// Initialize OpenGL context
	InitOpenGL();

	// Create the DX11device 
	g_pd3dDevice = CreateDX11device();

	// Create the interop device
	g_hInteropDevice = wglDXOpenDeviceNV(g_pd3dDevice);

	// Main loop
	int key = 0;
	g_Width  = 640;
	g_Height = 360;
	DWORD dwError = 0;

	for (int n=0; n<ntests; n++) {

		// ESC to break
		if (_kbhit()) {
			key = _getch();
			if (key == VK_ESCAPE)
				break;
		}

		// Spout receiver options
		// Start any sender before selecting options 1-3

		// Release all textures
		CleanupTextures();

		// Wait 4 frames
		// Sleep(67);
		Sleep(10);

		// Create the OpenGL texture
		glGenTextures(1, &g_glTexture);

		// Check for a sender and open the share handle
		if (option > 0) {

			// Any sender running?
			if (!senders.GetActiveSender(sendername)) {
				printf("No sender\n");
				// quit
				return 0;
			}

			// Get the sender info
			SharedTextureInfo info={};
			senders.getSharedInfo(sendername, &info);

			// The sender shared texture handle
			g_dxShareHandle = UIntToPtr(info.shareHandle);

			// Sender dimensions
			g_Width  = info.width;
			g_Height = info.height;

			//
			// Open a texture from the sender share handle
			//
			if (option == 1) {
				//
				// Option  1 - open a D3D11 texture from the sender handle and link with OpenGL
				//
				// *** wglDXRegisterObjectNV / wglDXUnregisterObjectNV cause a leak
				//
				printf("Open D3D11 texture texture from sender handle (%4dx%4d) - %d\n", g_Width, g_Height, n);
				if (!OpenDX11shareHandle(g_pd3dDevice, &g_pSharedTexture, g_dxShareHandle)) {
					// Flush because the shared texture is updated on this device
					FlushWait(g_pd3dDevice, g_pImmediateContext);
					printf("Open 1 OpenDX11shareHandle fail\n");
				}
			}
			else if (option == 2) {
				//
				// Option  2 - open a sender texture from the sender handle but don't use it
				//
				// There is no leak due to OpenSharedResource itself.
				//
				printf("Open sender texture from sender handle but don't use it (%4dx%4d) - %d\n", g_Width, g_Height, n);
				if (OpenDX11shareHandle(g_pd3dDevice, &g_pReceivedTexture, g_dxShareHandle)) {
					FlushWait(g_pd3dDevice, g_pImmediateContext);
					// Create and link a new shared texture instead
					CreateSharedDX11texture(g_pd3dDevice, g_Width, g_Height, (DXGI_FORMAT)87, &g_pSharedTexture, g_dxShareHandle);
				}
				else {
					printf("Open 2 OpenDX11shareHandle fail\n");
				}
			}
			else if (option == 3) {
				//
				// Option  3 - open a sender texture from the sender handle and copy to the D3D11 texture
				//
				// *** There is still a leak if the texture copied to is created with D3D11_RESOURCE_MISC_SHARED
				// but there is no leak if it is created with D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX (option 4).
				// The source sender shared texture can be created with either flag.
				// Unknown reason.
				//
				printf("Copy to shared D3D11 texture (%dx%d) - %d\n", g_Width, g_Height, n);
				if (OpenDX11shareHandle(g_pd3dDevice, &g_pReceivedTexture, g_dxShareHandle)) {
					CreateSharedDX11texture(g_pd3dDevice, g_Width, g_Height, (DXGI_FORMAT)87, &g_pSharedTexture, g_dxShareHandle);
					g_pImmediateContext->CopyResource(g_pSharedTexture, g_pReceivedTexture);
					dwError = GetLastError();
					if (dwError > 0) printf("CopyResource Error %d (0x%X)\n", dwError, dwError);
					FlushWait(g_pd3dDevice, g_pImmediateContext);
				}
				else {
					printf("Open 3 OpenDX11shareHandle fail\n");
				}
			}
			else if (option == 4) {
				//
				// Option  4 - open a sender texture from the sender handle and copy to the D3D11 texture
				// No leak if created with D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX.
				//
				printf("Copy to keyed mutex D3D11 texture (%dx%d) - %d\n", g_Width, g_Height, n);
				if (OpenDX11shareHandle(g_pd3dDevice, &g_pReceivedTexture, g_dxShareHandle)) {
					CreateSharedDX11texture(g_pd3dDevice, g_Width, g_Height, (DXGI_FORMAT)87, &g_pSharedTexture, g_dxShareHandle, true);
					g_pImmediateContext->CopyResource(g_pSharedTexture, g_pReceivedTexture);
					dwError = GetLastError();
					if (dwError > 0) printf("CopyResource Error %d (0x%X)\n", dwError, dwError);
					// Flush because the shared texture is updated on this device
					FlushWait(g_pd3dDevice, g_pImmediateContext);
				}
				else {
					printf("Open 4 OpenDX11shareHandle fail\n");
				}
			}
			if (g_pReceivedTexture) ReleaseDX11Texture(g_pd3dDevice, g_pReceivedTexture);
			g_pReceivedTexture = nullptr;

		}
		else {
			// Option 0 - Create and link a new D3D11 shared texture with OpenGL
			// No leak
			printf("Create new D3D11 texture (%4dx%4d) - test %d\n", g_Width, g_Height, n);
			CreateSharedDX11texture(g_pd3dDevice, g_Width, g_Height, (DXGI_FORMAT)87, &g_pSharedTexture, g_dxShareHandle);
		}

		//
		// Leak test
		//
		// wglDXOpenDeviceNV / wglDXCloseDeviceNV do not cause a memory leak
		//
		// wglDXRegisterObjectNV / wglDXUnregisterObjectNV cause a memory leak
		// if OpenSharedResource is used to obtain the texture pointer from
		// the handle of a shared texture produced by another process.
		//
		// wglDXLockObjectsNV / wglDXUnlockObjectsNV do not cause a memory leak
		// but D3D11 debug device ReportLiveDeviceObjects log shows 3 live 
		// ID3D11Buffer objects not released per cycle.
		//
		GLDXLeakTest(g_pSharedTexture, g_glTexture);

		// Memory report
		GLmemory();

	}

	CleanupTextures();
	if (g_hInteropDevice) wglDXCloseDeviceNV(g_hInteropDevice);
	if (g_pd3dDevice) ReleaseDX11device(g_pd3dDevice);
	wglMakeCurrent(NULL, NULL);
	wglDeleteContext(g_hRC);
	ReleaseDC(g_hWnd, g_hDC);
	DestroyWindow(g_hWnd);

	// Prevent the console from closing for user-mode debugger
#ifdef _DEBUG
	if (IsDebuggerPresent()) {
		printf("\nPress any key when ready to close and examine the debug output window...");
		_getch();
	}
#endif

	return 0;
}


// Repeated leak test
// Monitor "GLDXinteropLeak.exe" Dedicated memory with Task Manager > Details
void GLDXLeakTest(ID3D11Texture2D* pTexture, GLint glTexture)
{

	if (!pTexture || glTexture == 0) {
		printf("GLDXLeakTest null textures\n");
		return;
	}
	if (!g_pd3dDevice) {
		printf("GLDXLeakTest null device\n");
		return;
	}

	// Re-creating the device every time or once at the start makes no difference
	// create once at application start
	// g_hInteropDevice = wglDXOpenDeviceNV(g_pd3dDevice);

	if (g_hInteropDevice) {
		g_hInteropObject = wglDXRegisterObjectNV(g_hInteropDevice, pTexture, glTexture, GL_TEXTURE_2D, WGL_ACCESS_READ_WRITE_NV);
		if (g_hInteropObject) {

			// wglDXLockObjectsNV and wglDXUnlockObjectsNV 
			// No change in dedicated memory usage if omitted
			// However, debug log shows 3 live ID3D11Buffer objects not released
			if (wglDXLockObjectsNV(g_hInteropDevice, 1, &g_hInteropObject)) {
				if (!wglDXUnlockObjectsNV(g_hInteropDevice, 1, &g_hInteropObject))
					printf("wglDXUnlockObjectsNV fail\n");
			}
			else {
				printf("wglDXLockObjectsNV fail\n");
			}
			// Interop object must be released before releasing shared textures
			if (!wglDXUnregisterObjectNV(g_hInteropDevice, g_hInteropObject)) printf("wglDXUnregisterObjectNV fail\n");
			g_hInteropObject = nullptr;
		}
		else {
			printf("null hInteropObject\n");
		}
		
		// Close at application end
		// if (!wglDXCloseDeviceNV(g_hInteropDevice)) printf("wglDXCloseDeviceNV fail\n");
		// g_hInteropDevice = nullptr;
	}
	else {
		printf("null hInteropDevice\n");
	}

}



void InitWglProcs()
{
	wglDXOpenDeviceNV = (PFNWGLDXOPENDEVICENVPROC)wglGetProcAddress("wglDXOpenDeviceNV");
	wglDXSetResourceShareHandleNV = (PFNWGLDXSETRESOURCESHAREHANDLENVPROC)wglGetProcAddress("wglDXSetResourceShareHandleNV");
	wglDXRegisterObjectNV = (PFNWGLDXREGISTEROBJECTNVPROC)wglGetProcAddress("wglDXRegisterObjectNV");
	wglDXUnregisterObjectNV = (PFNWGLDXUNREGISTEROBJECTNVPROC)wglGetProcAddress("wglDXUnregisterObjectNV");
	wglDXCloseDeviceNV = (PFNWGLDXCLOSEDEVICENVPROC)wglGetProcAddress("wglDXCloseDeviceNV");
	wglDXLockObjectsNV = (PFNWGLDXLOCKOBJECTSNVPROC)wglGetProcAddress("wglDXLockObjectsNV");
	wglDXUnlockObjectsNV = (PFNWGLDXUNLOCKOBJECTSNVPROC)wglGetProcAddress("wglDXUnlockObjectsNV");
}

void InitOpenGL()
{
	// Create an invisible dummy button window
	g_hWnd = CreateWindowA("BUTTON", "DXGL", WS_OVERLAPPEDWINDOW | CS_OWNDC, 0, 0, 32, 32, NULL, NULL, NULL, NULL);

	g_hDC = GetDC(g_hWnd);
	if (g_hDC) {
		PIXELFORMATDESCRIPTOR pfd ={0};
		pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
		pfd.nVersion = 1;
		pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_SWAP_COPY;
		pfd.iPixelType = PFD_TYPE_RGBA;
		pfd.cColorBits = 24;
		pfd.cAlphaBits = 8;
		pfd.iLayerType = PFD_MAIN_PLANE;
		int pixelFormat = ChoosePixelFormat(g_hDC, &pfd);
		if (pixelFormat && SetPixelFormat(g_hDC, pixelFormat, &pfd)) {
			if (g_hRC = wglCreateContext(g_hDC)) {
				wglMakeCurrent(g_hDC, g_hRC);
			}
		}
		g_hRC = wglCreateContext(g_hDC);

		// Initialize interop procedures
		InitWglProcs();

	}
}

// Create DX11 device
ID3D11Device* CreateDX11device()
{
	ID3D11Device* pd3dDevice = nullptr;
	HRESULT hr = S_OK;
	UINT createDeviceFlags = 0;

	// If the project is in a debug build, enable debugging via SDK Layers with this flag.
	// https://docs.microsoft.com/en-us/windows/win32/api/d3d11/ne-d3d11-d3d11_create_device_flag
	// To use this flag, you must have D3D11_1SDKLayers.dll installed or device creation fails.
	// To resolve this, install the Windows 10 SDK.
	// Due to this dependency problem, manually remove the three lines below if necessary.
	// See ReleaseDX11device
#if defined(_DEBUG)
	createDeviceFlags |= D3D11_CREATE_DEVICE_DEBUG;
#endif

	// GL/DX interop Spec
	// ID3D11Device can only be used on WDDM operating systems : Must be multithreaded
	// D3D11_CREATE_DEVICE_FLAG createDeviceFlags
	D3D_DRIVER_TYPE driverTypes[] ={
		D3D_DRIVER_TYPE_HARDWARE,
		D3D_DRIVER_TYPE_WARP,
		D3D_DRIVER_TYPE_REFERENCE,
	};

	UINT numDriverTypes = ARRAYSIZE(driverTypes);

	D3D_FEATURE_LEVEL featureLevel;
	D3D_FEATURE_LEVEL featureLevels[] ={
		// D3D_FEATURE_LEVEL_11_1, // 0xb001 - hardware dependent
		D3D_FEATURE_LEVEL_11_0, // 0xb000
		D3D_FEATURE_LEVEL_10_1, // 0xa100
		D3D_FEATURE_LEVEL_10_0, // 0xa000
	};

	UINT numFeatureLevels = ARRAYSIZE(featureLevels);
	D3D_DRIVER_TYPE driverType;
	for (UINT driverTypeIndex = 0; driverTypeIndex < numDriverTypes; driverTypeIndex++) {
		driverType = driverTypes[driverTypeIndex];
		hr = D3D11CreateDevice(NULL,
			driverType,
			NULL,
			createDeviceFlags,
			featureLevels,
			numFeatureLevels,
			D3D11_SDK_VERSION,
			&pd3dDevice,
			&featureLevel,
			&g_pImmediateContext);
		// Break as soon as something passes
		if (SUCCEEDED(hr))
			break;
	}

	// Quit if nothing worked
	if (FAILED(hr)) {
		printf("CreateDX11device NULL device\n");
		return NULL;
	}

	// All OK - return the device pointer to the caller
	// g_pImmediateContext has also been created

	return pd3dDevice;

} // end CreateDX11device


unsigned long ReleaseDX11device(ID3D11Device* pd3dDevice)
{
	if (!pd3dDevice) {
		printf("ReleaseDX11device - null device\n");
		return 0;
	}

	// Release the global context or there is an outstanding ref count
	// when the device is released
	if (g_pImmediateContext) {
		g_pImmediateContext->Release();
	}

	// Use this for debugging if you have D3D11_1SDKLayers.dll installed and build Debug 
	// See - CreateDX11device
	// Remove if D3D11_1SDKLayers.dll is not installed (see DebugLog function)
	DebugLog(pd3dDevice, "ReleaseDX11Device (0x%.7X) context = (0x%.7X)\n",
		PtrToUint(pd3dDevice), PtrToUint(g_pImmediateContext));

	unsigned long refcount = pd3dDevice->Release();
	printf("ReleaseDX11device (0x%.7X) - refcount = %lu \n", PtrToUint(pd3dDevice), refcount);

	// null globals
	g_pd3dDevice = nullptr;
	g_pImmediateContext = nullptr;

	return refcount;
}


bool CreateSharedDX11texture(ID3D11Device* pd3dDevice,
	unsigned int width, unsigned int height, DXGI_FORMAT format,
	ID3D11Texture2D** ppSharedTexture, HANDLE& dxShareHandle, bool bKeyed)
{
	if (!pd3dDevice) {
		printf("CreateSharedDX11Texture NULL device\n");
		return false;
	}

	if (!ppSharedTexture) {
		printf("CreateSharedDX11Texture NULL ppSharedTexture\n");
		return false;
	}

	//
	// Create a new shared DX11 texture
	//

	// Release the texture if it already exists
	if (*ppSharedTexture)
		ReleaseDX11Texture(pd3dDevice, *ppSharedTexture);

	// Use the format passed in or if zero or DX9 format, use the default BGRA format
	DXGI_FORMAT texformat = format;
	if (format == 0 || format == 21 || format == 22) // D3DFMT_A8R8G8B8 = 21 D3DFMT_X8R8G8B8 = 22
		texformat = DXGI_FORMAT_B8G8R8A8_UNORM;

	// http://msdn.microsoft.com/en-us/library/windows/desktop/ff476903%28v=vs.85%29.aspx
	D3D11_TEXTURE2D_DESC desc;
	ZeroMemory(&desc, sizeof(desc));
	desc.Width = width;
	desc.Height = height;
	desc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
	if(bKeyed)
		desc.MiscFlags = D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
	else
		desc.MiscFlags = D3D11_RESOURCE_MISC_SHARED;
	desc.CPUAccessFlags = 0;
	desc.Format = texformat;
	desc.Usage = D3D11_USAGE_DEFAULT;
	desc.SampleDesc.Quality = 0;
	desc.SampleDesc.Count = 1;
	desc.MipLevels = 1;
	desc.ArraySize = 1;

	HRESULT res = pd3dDevice->CreateTexture2D(&desc, NULL, ppSharedTexture);

	if (FAILED(res)) {
		// http://msdn.microsoft.com/en-us/library/windows/desktop/ff476174%28v=vs.85%29.aspx
		char tmp[256];
		sprintf_s(tmp, 256, "CreateSharedDX11Texture ERROR - [0x%.X] : ", LOWORD(res));
		switch (LOWORD(res)) {
		case DXGI_ERROR_INVALID_CALL:
			strcat_s(tmp, 256, "DXGI_ERROR_INVALID_CALL");
			break;
		case E_INVALIDARG:
			strcat_s(tmp, 256, "E_INVALIDARG");
			break;
		case E_OUTOFMEMORY:
			strcat_s(tmp, 256, "E_OUTOFMEMORY");
			break;
		default:
			strcat_s(tmp, 256, "Unlisted error");
			break;
		}
		printf("%s\n", tmp);
		return false;
	}

	// Get the texture share handle
	ID3D11Texture2D* pTexture = *ppSharedTexture;
	IDXGIResource* pOtherResource = nullptr;
	if (pTexture) {
		if (FAILED(pTexture->QueryInterface(__uuidof(IDXGIResource), (void**)&pOtherResource))) {
			printf("CreateSharedDX11Texture - QueryInterface error\n");
			return false;
		}
	}
	if (!pOtherResource) {
		printf("CreateSharedDX11Texture - query resource error");
		return false;
	}

	// Return the shared texture handle
	pOtherResource->GetSharedHandle(&dxShareHandle);
	pOtherResource->Release();

	return true;

}


unsigned long ReleaseDX11Texture(ID3D11Device* pd3dDevice, ID3D11Texture2D* pTexture)
{
	if (!pd3dDevice || !pTexture) {
		if (!pd3dDevice)
			printf("ReleaseDX11Texture - no device\n");
		if (!pTexture)
			printf("ReleaseDX11Texture - no texture\n");
		return 0;
	}

	unsigned long refcount = pTexture->Release();
	pTexture = nullptr;

	// The device will be live, so warn if refcount > 1
	if (refcount > 1) {
		printf("ReleaseDX11Texture - refcount = %lu\n", refcount);
		DebugLog(pd3dDevice, "ReleaseDX11Texture - refcount = %lu\n", refcount);
	}

	// Note that if the texture is registered and linked to OpenGL using the 
	// GL/DX interop, the interop must be unregistered or the texture is not
	// released even though the reference count reported here does not increase.
	// In this test, the interop is unregistered before texture release.

	return refcount;
}

//---------------------------------------------------------
// Function: OpenDX11shareHandle
// Retrieve the pointer of a DirectX11 shared texture
bool OpenDX11shareHandle(ID3D11Device* pDevice, ID3D11Texture2D** ppSharedTexture, HANDLE dxShareHandle)
{
	if (!pDevice || !ppSharedTexture || !dxShareHandle) {
		printf("OpenDX11shareHandle - null sources\n");
		return false;
	}
	
	// Microsoft OpenSharedResource documentation method
	ID3D11Resource* tempResource11=nullptr;
	const HRESULT hr = pDevice->OpenSharedResource(dxShareHandle, __uuidof(ID3D11Resource), (void**)(&tempResource11));
	tempResource11->QueryInterface(__uuidof(ID3D11Texture2D), (void**)(ppSharedTexture));
	tempResource11->Release();

	// or
	// const HRESULT hr = pDevice->OpenSharedResource(dxShareHandle, __uuidof(ID3D11Texture2D), (void**)(ppSharedTexture));

	if (FAILED(hr)) {
		// Error 87 (0x75) - E_INVALIDARG
		printf("OpenDX11shareHandle (0x%.7X) failed : error = %d (0x%.7X)\n", PtrToUint(dxShareHandle), hr, hr);
		return false;
	}
	
	// ID3D11Texture2D * texturePointer = *ppSharedTexture;
	// printf("  OpenDX11shareHandle texture 0x%.7X\n", PtrToUint(texturePointer)); // 87
	// D3D11_TEXTURE2D_DESC td ={};
	// texturePointer->GetDesc(&td);
	// printf("td.Format = %d\n", td.Format); // 87
	// printf("td.Width = %d\n", td.Width);
	// printf("td.Height = %d\n", td.Height);
	// printf("td.MipLevels = %d\n", td.MipLevels);
	// printf("td.Usage = %d\n", td.Usage);
	// printf("td.ArraySize = %d\n", td.ArraySize);
	// printf("td.SampleDesc = %d\n", td.SampleDesc);
	// printf("td.BindFlags = %d\n", td.BindFlags);
	// printf("td.MiscFlags = %d\n", td.MiscFlags);
	
	return true;

}


void FlushWait(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pImmediateContext)
{
	// Flush to prevent deferred release
	pImmediateContext->ClearState();
	pImmediateContext->Flush();
	Wait(pd3dDevice, pImmediateContext); // ?? necessary

}

//---------------------------------------------------------
// Function: Wait
// Wait for completion after flush
void Wait(ID3D11Device* pd3dDevice, ID3D11DeviceContext* pImmediateContext)
{
	if (!pd3dDevice || !pImmediateContext)
		return;

	// https://msdn.microsoft.com/en-us/library/windows/desktop/ff476578%28v=vs.85%29.aspx
	// D3D11_QUERY_EVENT : Determines whether or not the GPU is finished processing commands.
	D3D11_QUERY_DESC queryDesc={};
	ID3D11Query* pQuery = nullptr;
	ZeroMemory(&queryDesc, sizeof(queryDesc));
	queryDesc.Query = D3D11_QUERY_EVENT;
	pd3dDevice->CreateQuery(&queryDesc, &pQuery);
	if (pQuery) {
		pImmediateContext->End(pQuery);
		// Wait for GetData to return S_OK
		while (S_OK != pImmediateContext->GetData(pQuery, NULL, 0, 0));
		pQuery->Release();
	}

}


//---------------------------------------------------------
void CleanupTextures()
{
	// Release OpenGL resources if there is a context
	if (wglGetCurrentContext()) {
		// Make sure no texture is bound
		glBindTexture(GL_TEXTURE_2D, 0);
		if (g_glTexture > 0)
			glDeleteTextures(1, &g_glTexture);
	}
	else {
		printf("CleanupTextures - no GL context");
	}

	// Release linked DirectX shared texture
	if (g_pSharedTexture)
		ReleaseDX11Texture(g_pd3dDevice, g_pSharedTexture);

	// Release received texture
	if (g_pReceivedTexture)
		ReleaseDX11Texture(g_pd3dDevice, g_pReceivedTexture);
	
	g_pSharedTexture = nullptr;
	g_dxShareHandle = nullptr;
	g_pReceivedTexture = nullptr;
	g_dxReceivedHandle = nullptr;

	// Flush to prevent deferred release
	FlushWait(g_pd3dDevice, g_pImmediateContext);

}


GLint GLmemory()
{

	// ATI TEXTURE_FREE_MEMORY_ATI 0x87FC
	glGetIntegerv(0x87FC, mem_kb);
	if (mem_kb[0] > 0) {
		// total memory free mem_kb[0]
		if (mem_kb[0] >= maxTotal)
			maxTotal = mem_kb[0];
		printf("ATI : \n");
		printf("total memory free   : %d KB\n", mem_kb[0]);
		printf("maximum since start : %d KB\n", maxTotal);
	}
	else {
		// NVIDIA
		// GPU_MEMORY_INFO_CURRENT_AVAILABLE_VIDMEM_NVX 0x9049
		// - current available dedicated video memory (in kb), currently unused GPU memory
		glGetIntegerv(0x9049, &mem_kb[0]);
		if (mem_kb[0] >= maxTotal)
			maxTotal = mem_kb[0];
		printf("current available memory : %d KB\n", mem_kb[0]);
		printf("maximum since start      : %d KB\n", maxTotal);
	}
	return mem_kb[0];
}

void DebugLog(ID3D11Device* pd3dDevice, const char* format, ...)
{

	if (!pd3dDevice)
		return;

	//
	// Output for debug using D3D11 SDK layers
	// (_DEBUG is defined for debug build)
	//

	// Suppress warning 26826 to use vsprintf_s
#pragma warning(disable:26485)
	// Construct the log now to avoid UNREFERENCED_PARAMETER warning if the block below is disabled
	char dlog[128]={};
	va_list args;
	va_start(args, format);
	// An explicit cast to the decayed pointer type prevents the warning
	vsprintf_s(dlog, 128, format, args);
	va_end(args);
#pragma warning(default:26485)

	// *** Manually comment out this section if D3D11_1SDKLayers.dll is not installed. ***
	// See comments CreateDX11device()

#ifdef _DEBUG

	// New line
	OutputDebugStringA("\n=========================================================\n");
	OutputDebugStringA(dlog);

	ID3D11Debug* DebugDevice = nullptr;
	if (pd3dDevice->QueryInterface(__uuidof(ID3D11Debug), (void**)&DebugDevice) == S_OK) {
		if (DebugDevice) {
			ID3D11InfoQueue* d3dInfoQueue = nullptr;
			if (SUCCEEDED(DebugDevice->QueryInterface(__uuidof(ID3D11InfoQueue), (void**)&d3dInfoQueue))) {
				d3dInfoQueue->SetBreakOnSeverity(D3D11_MESSAGE_SEVERITY_CORRUPTION, true);
				d3dInfoQueue->SetBreakOnSeverity(D3D11_MESSAGE_SEVERITY_ERROR, true);
				D3D11_MESSAGE_ID hide[] =
				{
					D3D11_MESSAGE_ID_SETPRIVATEDATA_CHANGINGPARAMS,
					// Add more message IDs here as needed
				};

				D3D11_INFO_QUEUE_FILTER filter;
				memset(&filter, 0, sizeof(filter));
				filter.DenyList.NumIDs = _countof(hide);
				filter.DenyList.pIDList = hide;
				d3dInfoQueue->AddStorageFilterEntries(&filter);

				// Print live objects to the debug Output window
				DebugDevice->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);

				d3dInfoQueue->Release();
			}
			DebugDevice->Release();
		}
	}
	OutputDebugStringA("=========================================================\n\n");

#endif

}



