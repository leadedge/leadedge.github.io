/*

	============
	DX11 version
	============



	SpoutLink - Receiver/Sender by direct access to shared textures

	Spout 2.007
	OpenFrameworks 10
	Visual Studio 2017

	Copyright (C) 2019-2020 Lynn Jarvis.

	=========================================================================
	This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with this program. If not, see <http://www.gnu.org/licenses/>.
	=========================================================================

	02.03.20 - Some tidy up - Version 1.001
			 - DirectX receive/send testing

*/
#include "ofApp.h"

// DIALOGS
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
static string NDInumber; // NDI library version number
static HINSTANCE g_hInstance;


//--------------------------------------------------------------
void ofApp::setup()
{

	ofBackground(0, 0, 0);

	EnableSpoutLog();

	// ofSetWindowTitle("SpoutLink");
	// Get instance
	g_hInstance = GetModuleHandle(NULL);

	// Window handle used for topmost function
	g_hWnd = WindowFromDC(wglGetCurrentDC());

	// Set the window title
	char title[256];
	strcpy_s(title, 256, "SpoutLink");
	ofSetWindowTitle(title); // show it on the title bar

	int windowWidth = ofGetWidth();
	int windowHeight = ofGetHeight() + GetSystemMetrics(SM_CYMENU);
	// Resize to the menu
	ofSetWindowShape(windowWidth, windowHeight);
	// Centre on the screen
	ofSetWindowPosition((ofGetScreenWidth() - windowWidth) / 2, (ofGetScreenHeight() - windowHeight) / 2);

	// Set a custom window icon
	HWND hwnd = WindowFromDC(wglGetCurrentDC());
	// SetClassLong(hwnd, GCL_HICON, (LONG)LoadIconA(GetModuleHandle(NULL), MAKEINTRESOURCEA(IDI_ICON1)));
	SetClassLong(hwnd, GCLP_HICON, (LONG)LoadIconA(GetModuleHandle(NULL), MAKEINTRESOURCEA(IDI_ICON1)));

	// Load a font rather than the default
	if (!myFont.load("fonts/verdana.ttf", 12, true, true))
		printf("Font not loaded\n");

	// Remove maximize button
	DWORD dwStyle = GetWindowLong(g_hWnd, GWL_STYLE);
	SetWindowLong(g_hWnd, GWL_STYLE, dwStyle ^= WS_MAXIMIZEBOX);

	// Disable escape key exit
	ofSetEscapeQuitsApp(false);

	//
	// Create a menu using ofxWinMenu
	//

	// A new menu object with a pointer to this class
	menu = new ofxWinMenu(this, g_hWnd);

	// Register an ofApp function that is called when a menu item is selected.
	// The function can be called anything but must exist. 
	// See the example "appMenuFunction".
	menu->CreateMenuFunction(&ofApp::appMenuFunction);

	// Create a window menu
	HMENU hMenu = menu->CreateWindowMenu();

	//
	// Create a "File" popup menu
	//
	HMENU hPopup = menu->AddPopupMenu(hMenu, "File");
	// Add popup items to the File menu
	menu->AddPopupItem(hPopup, "Open", false, false);
	// Final File popup menu item is "Exit" - add a separator before it
	menu->AddPopupSeparator(hPopup);
	menu->AddPopupItem(hPopup, "Exit", false, false);

	//
	// Window popup
	//
	hPopup = menu->AddPopupMenu(hMenu, "Window");
	bShowInfo = true;
	menu->AddPopupItem(hPopup, "Show info", true); // Checked and auto-check
	// Toggle receive to OpenGL to save time
	bDrawTexture = true;
	menu->AddPopupItem(hPopup, "Show graphics", true); // Checked and auto-check

	//
	// Help popup menu
	//
	hPopup = menu->AddPopupMenu(hMenu, "Help");
	menu->AddPopupItem(hPopup, "Information", false, false); // No auto check
	// menu->AddPopupItem(hPopup, "Documentation", false, false); // No auto check
	menu->AddPopupItem(hPopup, "About", false, false); // No auto check

	// Set the menu to the window
	menu->SetWindowMenu();

	// Allocate an RGBA texture to receive from the sender
	// It will be resized later to match the sender - see Update()
	myTexture.allocate(ofGetWidth(), ofGetHeight(), GL_RGBA);

	// EnableSpoutLog();
	// EnableSpoutLogFile("SpoutLink.log");
	// OpenSpoutConsole();

	// Toggle receive to OpenGL to save time
	bDrawTexture = true;

	// Toggle GPU memory display - TODO
	bShowGPU = true;

	// Get the GPU memory at the beginning for leak debugging
	GetGPUmemory(TotalGPUmemory, StartGPUmemory, CurrentGPUmemory, EvictedGPUmemory);

	ofDisableArbTex();

	// TODO : check
	// if (receiver.spout.GetDX9())
		// receiver.spout.SetDX9(false);

	// ===========================================
	// Create a BGRA directX texture for receiving
	// with or without keyed mutex
	receiver.spout.interop.OpenDirectX11();
	receiver_DX11device = receiver.spout.interop.m_pd3dDevice;

	printf("Creating shared texture %dx%d\n", ofGetWidth(), ofGetHeight());

	senderwidth = ofGetWidth();
	senderheight = ofGetHeight();
	receiver.spout.interop.spoutdx.CreateSharedDX11Texture(receiver_DX11device,
		senderwidth,
		senderheight,
		DXGI_FORMAT_B8G8R8A8_UNORM,
		&receiver_DX11texture,
		dxSharehandle);

	// Create a sender from the receiving texture sharehandle
	// The sender is a separate object so open DX11 for it
	sender.spout.interop.OpenDirectX11();
	if (sender.spout.interop.senders.CreateSender("SpoutLink", senderwidth, senderheight, dxSharehandle, 87)) {
		printf("sender created\n");
	}
	// ===========================================
	
	ofSetVerticalSync(false);


} // end setup


//--------------------------------------------------------------
void ofApp::update() {

	/*
	// If IsUpdated() returns true, the connected sender size has changed
	// and the receiving texture or pixel buffer must be re-sized.
	if (receiver.IsUpdated()) {
		myTexture.allocate(receiver.GetSenderWidth(), receiver.GetSenderHeight(), GL_RGBA);
		// Update our sender with the new size
		if (sender.IsInitialized()) {
			sender.UpdateSender("SpoutLink", receiver.GetSenderWidth(), receiver.GetSenderHeight());
		}
	}
	*/

}


void ofApp::draw() {

	// Get details of a connected sender but do not read the shared texture
	// TODO : ReceiveSenderData
	if (receiver.ReceiveTextureData()) {

		// printf("Received sender data\n");

		// Update local texture if sizes are different
		// TODO : IsUpdated
		if (receiver.GetSenderWidth() != senderwidth || receiver.GetSenderHeight() != senderheight) {
			printf("Updating sender from %dx%d to %dx%d\n",	senderwidth, senderheight, receiver.GetSenderWidth(), receiver.GetSenderHeight());
			senderwidth = receiver.GetSenderWidth();
			senderheight = receiver.GetSenderHeight();
			// Update the receiving texture from the connected sender share handle
			receiver.spout.interop.spoutdx.CreateSharedDX11Texture(receiver_DX11device,
				senderwidth, senderheight,
				DXGI_FORMAT_B8G8R8A8_UNORM,
				&receiver_DX11texture,
				dxSharehandle);
			// Update our own sender
			sender.spout.interop.senders.UpdateSender("SpoutLink", senderwidth, senderheight, dxSharehandle);
		}

		// Receive into the local DX11 texture
		// std::chrono::steady_clock::time_point startread;
		// std::chrono::steady_clock::time_point endread;
		// double elapsed = 0.0;

		// startread = std::chrono::steady_clock::now();
		receiver.spout.interop.ReadTexture(&receiver_DX11texture);
		// endread = std::chrono::steady_clock::now();
		// elapsed = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(endread - startread).count());
		// printf("ReadTexture : %f microseconds\n", elapsed);

		// If receiving from self go no further
		if (strcmp(receiver.GetSenderName(), "SpoutLink") == 0) {
			if (bShowInfo) showInfo();
			return;
		}
		
		// Draw if data has been received and the user wants to display
		if (bDrawTexture)
			myTexture.draw(0, 0, ofGetWidth(), ofGetHeight());

		// std::chrono::steady_clock::time_point startwrite;
		// std::chrono::steady_clock::time_point endwrite;

		// startwrite = std::chrono::steady_clock::now();
		receiver.spout.interop.WriteTexture(&receiver_DX11texture);
		// endwrite = std::chrono::steady_clock::now();

		// elapsed = static_cast<double>(std::chrono::duration_cast<std::chrono::microseconds>(endwrite - startwrite).count());
		// printf("WriteTexture : %f microseconds\n", elapsed);

		/*
		// if (!sender.IsInitialized()) {
		// if(!sender.spout.interop.senders.FindSenderName("SpoutLink")) {
			// sender.CreateSender("SpoutLink", receiver.GetSenderWidth(), receiver.GetSenderHeight(), 87);
			
			
			// Create a sender from the receiving texture sharehandle
			// if (sender.spout.interop.senders.CreateSender("SpoutLink", receiver.GetSenderWidth(), receiver.GetSenderHeight(), dxSharehandle, 87)) {
				// printf("sender created\n");
			// }
		}
		else {	
			// Check for connected sender changes here before writing the texture
			// Normally a receiver would not send as well
			// Changes are made in update()
			if (!receiver.IsUpdated()) {
				// sender.SendTexture(myTexture.getTextureData().textureID, myTexture.getTextureData().textureTarget,
					// receiver.GetSenderWidth(), receiver.GetSenderHeight());
				sender.spout.interop.WriteTexture(&DX11texture);
			}
		}
		*/

	}

	// On-screen display
	if(bShowInfo)
		showInfo();

}

//--------------------------------------------------------------
void ofApp::showInfo() {

	char str[256];
	ofSetColor(255);

	if (receiver.IsConnected()) {
		if (strcmp(receiver.GetSenderName(), "SpoutLink") != 0) {
			// Applications < 2.007 will return no frame count information
			// Frame counting can also be disabled in SpoutSettings
			if (receiver.GetSenderFrame() > 0) {
				sprintf_s(str, 256, "Receiving : [%s] (%dx%d : fps %2.0f : frame %d)",
					receiver.GetSenderName(), // sender name
					receiver.GetSenderWidth(), // width
					receiver.GetSenderHeight(), // height 
					receiver.GetSenderFps(), // fps
					receiver.GetSenderFrame()); // frame since the sender started
			}
			else {
				sprintf_s(str, 256, "Receiving : [%s] (%dx%d)",
					receiver.GetSenderName(),
					receiver.GetSenderWidth(),
					receiver.GetSenderHeight());
			}
			myFont.drawString(str, 10, 20);
			// if (!receiver.GetDX9())
				sprintf_s(str, 256, "Sending as [SpoutLink] : fps (%2.0f)", ofGetFrameRate());
			// else
				// sprintf_s(str, 256, "DX9 mode incompatible with SpoutLink\nPlease close and change mode with SpoutSettings");
			myFont.drawString(str, 10, 40);
		}
		else {
			sprintf_s(str, 256, "Cannot receive from self. Select another sender.");
			myFont.drawString(str, 10, 20);
		}
		sprintf_s(str, 256, "RH click select sender : SPACE to toggle draw");
		myFont.drawString(str, 20, ofGetHeight() - 20);
	}
	else {
		sprintf_s(str, 256, "No sender detected");
		myFont.drawString(str, 10, 20);
	}

	// GPU usage display for leak debugging
	// Can also use TotalGPUmemory, StartGPUmemory
	if (bShowGPU) {
		float totalMb = 0.0f;
		float availMb = 0.0f;
		float currentMb = 0.0;
		float evictedMb = 0.0f;
		GetGPUmemory(totalMb, availMb, currentMb, evictedMb);
		float usedMb = totalMb - currentMb; // -StartGPUmemory);
		float usedAppMb = StartGPUmemory - availMb; // -StartGPUmemory);
		sprintf_s(str, 256, "OpenGL GPU mb : Available %4.0f : Current %4.0f : Used %4.0f",
			availMb, currentMb, usedMb);
		myFont.drawString(str, 20, ofGetHeight() - 40);
	}

}

// Check free GPU memory
// http://developer.download.nvidia.com/opengl/specs/GL_NVX_gpu_memory_info.txt
// GPU_MEMORY_INFO_DEDICATED_VIDMEM_NVX			0x9047
// GL_GPU_MEM_INFO_TOTAL_AVAILABLE_MEM_NVX		0x9048
// GL_GPU_MEM_INFO_CURRENT_AVAILABLE_MEM_NVX	0x9049
// GPU_MEMORY_INFO_EVICTED_MEMORY_NVX			0x904B
// GL_NVX_gpu_memory_info returns sizes in KB
void ofApp::GetGPUmemory(float &total, float &available, float &current, float &evicted)
{
	int totalMemory = 0;
	int availableMemory = 0;
	int currentMemory = 0;
	int evictedMemory = 0;
	glGetIntegerv(0x9047, &totalMemory);
	glGetIntegerv(0x9048, &availableMemory);
	glGetIntegerv(0x9049, &currentMemory);
	glGetIntegerv(0x904B, &evictedMemory);
	total = (float)totalMemory / (1024.0f);
	available = (float)availableMemory / (1024.0f);
	current = (float)currentMemory / (1024.0f);
	evicted = (float)evictedMemory / (1024.0f);
}

//--------------------------------------------------------------
void ofApp::exit() {
	receiver.ReleaseReceiver();
	sender.ReleaseSender();
	receiver.spout.interop.spoutdx.ReleaseDX11Texture(receiver_DX11device, receiver_DX11texture);

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	if (button == 2) { // rh button
		// Open the sender selection panel
		// Spout must have been installed
		receiver.SelectSender();
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {
	if (key == VK_SPACE) {
		bDrawTexture = !bDrawTexture;
		menu->SetPopupItem("Show graphics", bDrawTexture);
	}
}



//--------------------------------------------------------------
//
// Menu function callback
//
// This function is called by ofxWinMenu when an item is selected.
// The the title and state can be checked for required action.
// 
void ofApp::appMenuFunction(string title, bool bChecked) {

	//
	// File menu
	//

	if (title == "Open") {
		receiver.SelectSender();
	}

	if (title == "Exit") {
		ofExit(); // Quit the application
	}

	//
	// Window menu
	//

	if (title == "Show info") {
		bShowInfo = bChecked;
	}

	if (title == "Show graphics") {
		bDrawTexture = bChecked;
	}

	//
	// Help menu
	//
	if (title == "Information") {
		string text = "Performance is improved if graphics is not shown.\n";
		text += "NVIDIA graphics performance can be affected\n";
		text += "by 'Threaded optimization'. If so, set it OFF\n";
		text += "in the NVIDIA control panel 3D settings.";
		MessageBoxA(NULL, text.c_str(), "Information", MB_OK | MB_TOPMOST);
	}


	if (title == "About") {
		DialogBoxA(g_hInstance, MAKEINTRESOURCEA(IDD_ABOUTBOX), g_hWnd, About);
	}

	/*
	if (title == "Documentation") {
		char path[MAX_PATH];
		HMODULE hModule = GetModuleHandle(NULL);
		GetModuleFileNameA(hModule, path, MAX_PATH);
		PathRemoveFileSpecA(path);
		strcat_s(path, MAX_PATH, "\\SpoutLink.pdf");
		ShellExecuteA(g_hWnd, "open", path, NULL, NULL, SW_SHOWNORMAL);
	}
	*/


} // end appMenuFunction


// Message handler for About box
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	char tmp[MAX_PATH];
	char about[1024];
	DWORD dummy, dwSize;
	LPDRAWITEMSTRUCT lpdis;
	HWND hwnd = NULL;
	HCURSOR cursorHand = NULL;
	HINSTANCE hInstance = GetModuleHandle(NULL);

	switch (message) {

	case WM_INITDIALOG:

		sprintf_s(about, 256, "SpoutLink - Version ");
		// Get product version number
		if (GetModuleFileNameA(hInstance, tmp, MAX_PATH)) {
			dwSize = GetFileVersionInfoSizeA(tmp, &dummy);
			if (dwSize > 0) {
				vector<BYTE> data(dwSize);
				if (GetFileVersionInfoA(tmp, NULL, dwSize, &data[0])) {
					LPVOID pvProductVersion = NULL;
					unsigned int iProductVersionLen = 0;
					if (VerQueryValueA(&data[0], ("\\StringFileInfo\\080904E4\\ProductVersion"), &pvProductVersion, &iProductVersionLen)) {
						sprintf_s(tmp, MAX_PATH, "%s\n", (char *)pvProductVersion);
						strcat_s(about, 1024, tmp);
					}
				}
			}
		}
		strcat_s(about, 1024, "\n\n");
		strcat_s(about, 1024, "Receive from any sender\n");
		strcat_s(about, 1024, "Send in DirectX 9 compatible format\n");
		strcat_s(about, 1024, "DXGI_FORMAT_B8G8R8A8_UNORM\n\n");
		strcat_s(about, 1024, "If you find Spout useful, please\n");
		strcat_s(about, 1024, "consider a donation to the project");


		/*
		// Newtek credit - see resource,rc
		strcat_s(about, 1024, "  NewTek NDI� - Version ");
		// Add NewTek library version number (dll)
		strcat_s(about, 1024, NDInumber.c_str());
		strcat_s(about, 1024, "\n  NDI� is a trademark of NewTek, Inc.");
		*/

		SetDlgItemTextA(hDlg, IDC_ABOUT_TEXT, (LPCSTR)about);

		//
		// Hyperlink hand cursors
		//

		// Spout
		cursorHand = LoadCursor(NULL, IDC_HAND);
		hwnd = GetDlgItem(hDlg, IDC_SPOUT_URL);
		// SetClassLongA(hwnd, GCL_HCURSOR, (long)cursorHand);
		SetClassLongA(hwnd, GCLP_HCURSOR, (long)cursorHand);

		/*
		// NDI
		hwnd = GetDlgItem(hDlg, IDC_NEWTEC_URL);
		SetClassLong(hwnd, GCL_HCURSOR, (long)cursorHand);
		*/

		break;


	case WM_DRAWITEM:

		// The blue hyperlinks
		lpdis = (LPDRAWITEMSTRUCT)lParam;
		if (lpdis->itemID == -1) break;
		SetTextColor(lpdis->hDC, RGB(6, 69, 173));
		switch (lpdis->CtlID) {
			// case IDC_NEWTEC_URL:
				// DrawTextA(lpdis->hDC, "http://NDI.NewTek.com", -1, &lpdis->rcItem, DT_LEFT);
				// break;
			case IDC_SPOUT_URL:
				DrawTextA(lpdis->hDC, "http://spout.zeal.co", -1, &lpdis->rcItem, DT_LEFT);
				break;
			default:
				break;
		}
		
		break;

	case WM_COMMAND:

		/*
		if (LOWORD(wParam) == IDC_NEWTEC_URL) {
			sprintf_s(tmp, MAX_PATH, "http://NDI.NewTek.com");
			ShellExecuteA(hDlg, "open", tmp, NULL, NULL, SW_SHOWNORMAL);
			EndDialog(hDlg, 0);
			return (INT_PTR)TRUE;
		}
		*/

		if (LOWORD(wParam) == IDC_SPOUT_URL) {
			sprintf_s(tmp, MAX_PATH, "http://spout.zeal.co");
			ShellExecuteA(hDlg, "open", tmp, NULL, NULL, SW_SHOWNORMAL);
			EndDialog(hDlg, 0);
			return (INT_PTR)TRUE;
		}

		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) {
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

