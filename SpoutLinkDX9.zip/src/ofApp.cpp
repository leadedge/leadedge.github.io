/*

	            SpoutLinkDX9

	Idea for converting DX9 to DX11 before Spout send
	to avoid DX9 compatibility problems with receivers
	
	1) Receive a DX9 shared texture using SpoutDX9
	2) Copy received shared texture to to DX11 texture
	3) Send DX11 texture with default BGRA texture format


	08.01.22 - Minimal project based on OpenGL SpoutLink

*/
#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup()
{
	ofBackground(0, 0, 0);

	// OpenSpoutConsole(); // For debug print

	// Set the window title
	ofSetWindowTitle("SpoutLinkDX9"); // show it on the title bar

	// Start window size
	int windowWidth = ofGetWidth();
	int windowHeight = ofGetHeight() + GetSystemMetrics(SM_CYMENU);

	// Disable escape key exit
	ofSetEscapeQuitsApp(false);

	// DX9
	// Create a D3D9ex device within the SpoutDirectX9 class.
	if (!DX9receiver.OpenDirectX9(ofGetWin32Window())) {
		MessageBoxA(NULL, "DX9receiver.OpenDirectX9 failed", "Error", MB_OK);
		ofExit();
	}
	// Get the SpoutDX9 class object and device
	g_pD3D9 = DX9receiver.GetDX9object();
	if (!g_pD3D9) {
		MessageBoxA(NULL, "DX9receiver.GetDX9object failed", "Error", MB_OK);
		ofExit();
	}
	g_pd3dDevice9 = DX9receiver.GetDX9device();
	if (!g_pd3dDevice9) {
		MessageBoxA(NULL, "DX9receiver.GetDX9device failed", "Error", MB_OK);
		ofExit();
	}

	// Set the receiver to connect to "NestDrop Deck 1"
	DX9receiver.SetReceiverName("NestDrop Deck 1");

	// DX11
	if (!DX11sender.OpenDirectX11()) {
		MessageBoxA(NULL, "DX11sender.OpenDirectX11 failed", "Error", MB_OK);
		ofExit();
	}
	g_pd3dDevice11 = DX11sender.GetDX11Device();
	g_pImmediateContext11 = DX11sender.GetDX11Context();
	DX11sender.SetSenderName("SpoutLinkDX9");


} // end setup


//--------------------------------------------------------------
void ofApp::update() {

}

void ofApp::draw() {
	
	// ReceiveTexture looks after sender connection and received texture re-sizing
	if (DX9receiver.ReceiveDX9Texture(g_pReceivedTexture9)) {
		// If receiving from self go no further
		if (strcmp(DX9receiver.GetSenderName(), "SpoutLinkDX9") == 0) {
			showInfo();
			return;
		}

		// Copy the received DX9 shared texture to a DX11 texture
		HANDLE DX9handle = DX9receiver.GetSenderHandle();
		IDXGIResource* tempResource11(NULL);
		g_pd3dDevice11->OpenSharedResource(DX9handle, __uuidof(ID3D11Resource), (void**)(&tempResource11));
		tempResource11->QueryInterface(__uuidof(ID3D11Texture2D), (void**)(&g_pTexture11));
		tempResource11->Release();

		// Send the DX11 texture
		DX11sender.SendTexture(g_pTexture11);

	}

	// On-screen display
	showInfo();

}

//--------------------------------------------------------------
void ofApp::showInfo() {

	char str[256];
	ofSetColor(255);

	if (DX9receiver.IsConnected()) {
		if (strcmp(DX9receiver.GetSenderName(), "SpoutLinkDX9") != 0) {
			if (DX9receiver.GetSenderFrame() > 0) {
				sprintf_s(str, 256, "Receiving : [%s] (%dx%d : fps %2.0f : frame %d)",
					DX9receiver.GetSenderName(),   // name
					DX9receiver.GetSenderWidth(),  // width
					DX9receiver.GetSenderHeight(), // height 
					DX9receiver.GetSenderFps(),    // fps
					DX9receiver.GetSenderFrame()); // frame since the sender started
			}
			else {
				sprintf_s(str, 256, "Receiving : [%s] (%dx%d)",
					DX9receiver.GetSenderName(),
					DX9receiver.GetSenderWidth(),
					DX9receiver.GetSenderHeight());
			}
			ofDrawBitmapString(str, 10, 20);
			if (DX11sender.IsInitialized()) {
				sprintf_s(str, 256, "Sending as [%s] : fps (%2.0f)",
					DX11sender.GetName(), ofGetFrameRate());
			}
			else {
				sprintf_s(str, 256, "DX11 sender not initialized");
			}
			ofDrawBitmapString(str, 10, 40);

		}
		else {
			sprintf_s(str, 256, "Cannot receive from self. Select another sender.");
			ofDrawBitmapString(str, 10, 20);
		}
	}
	else {
		sprintf_s(str, 256, "No sender detected");
		ofDrawBitmapString(str, 10, 20);
	}
	if (DX11sender.GetSenderCount() > 0) {
		sprintf_s(str, 256, "RH click to select sender");
		ofDrawBitmapString(str, 20, ofGetHeight() - 20);
	}

}

//--------------------------------------------------------------
void ofApp::exit() {

	DX9receiver.ReleaseReceiver();
	if (g_pReceivedTexture9)
		g_pReceivedTexture9->Release();
	DX9receiver.CloseDirectX9();
	g_pd3dDevice9 = nullptr;
	g_pD3D9 = nullptr;

	DX11sender.ReleaseSender();
	if (g_pTexture11)
		g_pTexture11->Release();
	DX11sender.CloseDirectX11();
	g_pImmediateContext11 = nullptr;
	g_pd3dDevice11 = nullptr;

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	if (button == 2) { // rh button
		// Open the sender selection panel
		// Spout must have been installed
		DX9receiver.SelectSender();
	}
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key) {

}

