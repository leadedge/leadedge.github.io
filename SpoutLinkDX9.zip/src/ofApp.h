/*
	SpoutLinkDX9

*/
#pragma once

#include "ofMain.h"
#include "..\SpoutDX\SpoutDX.h" // DX11
#include "..\SpoutDX9\SpoutDX9.h" // DX9

class ofApp : public ofBaseApp {

	public:

		void setup();
		void update();
		void draw();
		void exit();
		void mousePressed(int x, int y, int button);
		void keyPressed(int key);

		// DX9 receiver
		spoutDX9 DX9receiver;
		IDirect3D9Ex* g_pD3D9 = nullptr; // Used to create the D3DDevice
		IDirect3DDevice9Ex* g_pd3dDevice9 = nullptr; // Our device
		LPDIRECT3DTEXTURE9 g_pReceivedTexture9 = nullptr; // Texture received from a sender
		
		// DX11 sender
		spoutDX DX11sender;
		ID3D11Device* g_pd3dDevice11 = nullptr;
		ID3D11DeviceContext* g_pImmediateContext11 = nullptr;
		ID3D11Texture2D* g_pTexture11 = nullptr;

		void showInfo(); // On-screen information

};
