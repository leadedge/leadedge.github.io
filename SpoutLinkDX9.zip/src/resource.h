#ifndef IDC_STATIC
#define IDC_STATIC (-1)
#endif

#define IDI_ICON1           100
#define IDD_ABOUTBOX        200
#define IDC_ABOUT_TEXT      201
#define IDC_SPOUT_URL       202


