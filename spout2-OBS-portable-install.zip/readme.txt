
For OBS that has been installed, extract the zip file downloaded from 
"https://github.com/Off-World-Live/obs-spout2-plugin/releases"
(e.g. win-spout-1.9.0-windows-x64.zip)
into the "C:\ProgramData\obs-studio\plugins" folder.

For OBS portable, copy both the zip file and the batch file
into the root folder. For example :

   bin
   config
   data
   obs-plugins
portable-mode.txt
spout2-OBS-portable-install.bat
win-spout-1.9.0-windows-x64.zip

Run the batch file to copy the required files for OBS portable.
