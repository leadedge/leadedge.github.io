MILKDROP PLUGIN

vis_milk2.dll is a 32bit visualization plugin for Winamp modified for Spout output.

Copy vis_milk2.dll from the Spout distribution to the Winamp plugins folder.

Start Winamp and select : Options > Visualization > Select Plugin
and choose "MilkDrop v2.25c [vis_milk2.dll]"

Spout options are available in the Visualization configuration control panel :

Options -> Visualizations -> Configure Plugin

    MORE SETTINGS tab
      [ ] Enable Spout output (default ON)

Settings are saved with OK.

The Spout output can also be changed when the Visualization is running  :

Ctrl-Z to enable or disable

The selected settings are saved when the Visualizer is stopped.


Notes :

Winamp 5.666 has been recommended and tested for the plugin.
Version 5.8 has not been fully tested but all indications are that the plugin works OK.
Your feedback is welcome.
