Where did all the Spout plugins go ?

Most are not needed in the Spout distribution any more, because they are either built in or distributed with other applications.

Only the plugin for Winamp Milkdrop remains.

MAX/MSP

jit.gl.spoutsender and jit.gl.spoutreceiver are now available in the Max package manager
for both 32bit and 64bit. Max provides help files as examples.

PROCESSING

Spout for Processing is available as a contributed library.
Get it from your sketch Library import manager.
Examples are included in the distribution.
Source is available on GitHub : https://github.com/leadedge/SpoutProcessing

FREEFRAMEGL

Freeframe hosts for popular programs now include Spout built in and the 32 bit plugins are no longer necessary. 
However, source is available on GitHub : https://github.com/leadedge/Spout2

VVVV
DX9 version distributed with the latest Alphas. DX11 version avaliable as an addition.

VIRTUALDJ

64 bit plugins are available on GitHub : https://github.com/leadedge/SpoutVDJ
The receiver is experimantal and not recommended for performance work.


