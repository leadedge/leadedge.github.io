This archive can be extracted to any convenient folder.
Avoid folders that require administrator privileges.

To prepare Spout you need to do the following :

1) Uninstall any existing Spout installation.
Use Windows Control Panel or the uninstaller : C:\Program Files (x86)\Spout2\unins000.exe

2) SpoutCam
Run "SpoutCamSettings" and register SpoutCam.
SpoutCam registration can be removed using the same button.
Refer to readme.txt in the SPOUTCAM folder.

3) Settings
Run "SpoutSettings" and choose the settings you require.
CPU sharing mode option has been removed due to no advantage over Memory sharing.
The source for this will be removed from the Spout 2.007 SDK.
Click OK and close to save the settings in the registry. The settings will
remain there so if you want to remove Spout and clean the registry, use Regedit.
Look for and delete : HKEY_CURRENT_USER\Software\Leading Edge\Spout
Or if there are no ther Spout applications installed, remove :
HKEY_CURRENT_USER\Software\Leading Edge
Refer to readme.txt in the SPOUTSETTINGS folder.

4) SpoutPanel
Run SpoutPanel.exe once to save it's location in the registry for receiving applications.
After doing this, check that the location is registered using the Spout demo receiver.
RH click on the window and the SpoutPanel dialog should appear.
Again if you wish to remove Spout and clean the registry, use Regedit to find and delete :
Computer\HKEY_CURRENT_USER\Software\Leading Edge\SpoutPanel

5) Shortcuts
You may wish to make desktop shortcuts for the demo programs and SpoutSettings

6) Visual Studio 2017 runtimes
Spout utility programs are built with Visual Studio 2017.
If you get errors about missing dlls, you will need to install the runtime.
You need the latest redistributable for Visual Studio 2015, 2017 and 2019.

https://support.microsoft.com/en-au/help/2977003/the-latest-supported-visual-c-downloads

Spout programs are either 32bit or 64bit, so you need to download and install both runtimes.
Install the 64 bit version before the 32 bit version.

7) Documentation
Spout documentation will be updated with release 2.007.
Please direct any questions to the Spout Discourse group : https://spout.discourse.group/
