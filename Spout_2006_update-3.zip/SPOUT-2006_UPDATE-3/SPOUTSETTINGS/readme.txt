SPOUTSETTINGS

SpoutSettings is a program to change the operation mode for Spout applications.

DirectX 9

If DirectX9c is not installed you will see buttons to download the web installer or to download the installer file. DirectX 9c is required for DirectX 9 functions.

Options

o DirectX 9 - switch between DirectX 9 and DirectX 11 functions
o Buffer    - use OpenGL pixel buffering to copy data GPU < > CPU.

DX9 mode is not recommended as default. This might be necessary if your system requires it, but is not compatible with some applications. Pixel buffering is used for CPU texture access and memoryshare or for applications that transfer to textures from CPU memory. Buffering is faster but might result in latency. Test for your application.

Share mode

o Texture - OpenGL/DirectX interop for sharing textures
o Memory  - CPU memory for data sharing instead of DirectX

Texture share mode requires a graphics adapter compatible with the NVIDIA OpenGL/DirectX interop. Memory share mode uses shared CPU memory instead of shared GPU textures. It is a backup in case texture sharing is not supported by your system. 

All applications built with the Spout 2.006 SDK switch to the selected mode. Memory share mode does not have any effect for Spout 2.004 applications which only support texture sharing.

NVIDIA global processor

o for laptop computers with dual graphics and NVIDIA Optimus power saving technology.

The mode of operation can be changed to enable the high performance NVIDIA graphics globally for all applications. This over-rides the NVIDIA control panel settings and can be useful where there is difficulty in adjusting these settings. This does not have any effect if the computer does not have Optimus graphics or is not NVIDIA.

Maximum Senders

Sets the maximum number of simultaneous Spout senders. For this to apply, all running Spout applications must have been built with the 2.005 SDK or later. Applications built with 2.004 or earlier are limited to the default of 10 senders.



