SPOUT

"Spout" is a video frame sharing system for Microsoft Windows which allows applications to share OpenGL and DirectX textures between each other in a similar way to Syphon for the Mac. For compatible graphics hardware, textures are shared by way of DirectX using the NVIDIA DirectX/OpenGL interop extension.

Included with the Spout installation are :

  o SpoutSettings - a program to select settings for Spout
  o SpoutCam - a Virtual Webcam universal receiver 32/64 bit
  o SpoutPanel - a sender selection dialog that can be used by Spout receivers
  o Sender and receiver demonstration programs
  o A Milkdrop sender dll for Winamp

Many programs include Spout support.

Visit the website (http://spout.zeal.co/) or join the Spout discourse group (https://spout.discourse.group/).

