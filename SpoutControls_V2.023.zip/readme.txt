SpoutControls

SpoutControls enables a Spout receiver to control a Spout sender. A C++ class enables programmers to develop a controlled Spout Sender with C++ or Processing that will react to user controls specific to the application from a Spout controller.

SpoutController.dll is a FreeframeGL Spout Receiver plugin that controls a Spout sender.

The plugin provided with the original SpoutControls 1.010 distribution is built for FreeframeGL 1.6 and requires a compatible host, such as "Magic Music Visuals" (https://magicmusicvisuals.com/). 

https://github.com/leadedge/leadedge.github.io/raw/downloads/SpoutControls_setup_V1.010.zip

However this is not compatible with Resolume 7 (https://resolume.com/) which uses FreeframeGL 2. SpoutController2.dll is built with FreeframeGL 2.0 so that it can be used in place of the distribution version.

SpoutController FreeframeGL 2.0 update

https://github.com/leadedge/leadedge.github.io/raw/downloads/SpoutControls_V2.023.zip


==============================================================================
Copyright (C) 2015-2022. Lynn Jarvis, https://spout.zeal.co/.

This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.

You will receive a copy of the GNU Lesser General Public License along with this program.  If not, see http://www.gnu.org/licenses/.

