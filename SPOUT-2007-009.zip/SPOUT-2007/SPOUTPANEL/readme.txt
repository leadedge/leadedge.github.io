SPOUTPANEL

SpoutPanel is a utility program that will be activated by Spout receiver to select the sender to be received.

The path for SpoutPanel.exe is established by using SpoutSettings or opening the application once.

The sender texture button brings up sender details and diagnostics.

Computer type (Laptop/Desktop) and name.
Sender program and sender name.
Windows Graphics performace preference if set and preferred graphics adapter
Graphics adapter used by the sender.
Share mode (Texture or CPU).
Texture details.
Sender information.
Sender application path.

Click "Copy" to save them.
