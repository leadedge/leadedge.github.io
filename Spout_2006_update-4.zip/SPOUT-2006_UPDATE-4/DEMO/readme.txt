SpoutSender.exe and SpoutReceiver.exe are demonstration programs that can be used for testing purposes. Both 32-bit and 64-bit are included.

You can also build an Openframeworks version (https://github.com/leadedge/ofSpoutDemo).

