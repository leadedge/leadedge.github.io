SPOUTPANEL

SpoutPanel is a utility program that will be activated by Spout receiver to select the sender to be received.

The path for SpoutPanel.exe is established by using SpoutSettings or opening the application once.
