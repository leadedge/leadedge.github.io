SpoutDX examples using sync funtions

Tutorial07 receiver - SetFrameSync
Tutorial04 sender - WaitFrameSync

Search for SYNC TESTING in the source
Binaries for testing are in Tutorial04_Sync\BINARIES

To build, the rpository folders "SpoutDX" and SpoutGL" are required
Copy the two projects "Tutorial04_Sync" and "Tutorial07_Sync"
To the "SpoutDX" folder
Examples are built with Visual Studio 2022


